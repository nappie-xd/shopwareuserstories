import QuantityFieldPlugin from './script/quantity-field.plugin'

window.PluginManager.register('QuantityField', QuantityFieldPlugin, '[data-quantity-field]')