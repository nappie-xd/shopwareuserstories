<?php declare(strict_types=1);

namespace QuantitySelect;

use Shopware\Core\Framework\Plugin;

class QuantitySelect extends Plugin
{
}