import QuantitySelectPlugin from './script/quantity-select.plugin'

window.PluginManager.register('QuantitySelect', QuantitySelectPlugin, '[data-quantity-select]')