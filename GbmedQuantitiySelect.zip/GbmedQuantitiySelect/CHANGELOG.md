# 1.1.0
- 6.4.x compatibility

# 1.0.2
- Graduation added

# 1.0.1
- SW 6.2.x compatibility

# 1.0.0
- First release Shopware Community Store
